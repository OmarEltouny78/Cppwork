#pragma once
#include <vector>
using namespace std;
class Status {
private:
	bool trap;
	bool stun;
	bool isMoving;
	bool abilityEarned;
	vector<int> abilityGiven;
public:
	void setData(bool t, bool s, bool isM, bool aEarn, vector<int> abGiv) {
		t = trap;
		s = stun;
		isM = isMoving;
		aEarn = abilityEarned;
		abGiv = abilityGiven;
	}
};