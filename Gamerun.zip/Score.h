#pragma once
class Score {
private:
	int value;
	bool endgame;
	int lvlscore;
	bool lvlsurpassed;
public:
	void setData(int v, bool eg, int lvls, bool lvlsur) {
		v = value;
		eg = endgame;
		lvls = lvlscore;
		lvlsur = lvlsurpassed;
	}
	int getValue() {
		return value;
	}
	bool getEndGame() {
		return endgame;
	}
	int getLvlScore() {
		return lvlscore;
	}
	bool getLvlSurpassed() {
		return lvlsurpassed;
	}
};