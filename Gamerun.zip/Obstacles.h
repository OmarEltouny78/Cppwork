#pragma once
class Obstacles {
private:
	int size;
	int push;
	bool isStunning;
	bool isFrezze;
public:
	void setData(int s, int p, bool isS, bool isF) {
		s = size;
		p = push;
		isS = isStunning;
		isF = isFrezze;
	}
	int getSize() {
		return size;
	}
	int getPush() {
		return push;
	}
	bool getIsStunning() {
		return isStunning;
	}
	bool getIsFrezze() {
		return isFrezze;
	}
};
