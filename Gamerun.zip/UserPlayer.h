#pragma once
#include <vector>
#include <string>
using namespace std;
class PlayerUser {
private:
	vector<int> controls;
	int boost;
	bool stunned;
	bool froze;
	bool outOfWindow;
	int health;
	vector<int> abilities;
public:
	void setData(vector<int> c, int b, bool s, bool f, bool oow, int h, vector<int> abs) {
		c = controls;
		b = boost;
		s = stunned;
		f = froze;
		h = health;
		abs = abilities;
	}
	vector<int> getControls() {
		return controls;
	}
	int getBoost() {
		return boost;
	}
	bool getStunned() {
		return stunned;
	}
	bool getFroze() {
		return froze;
	}
	int getHealth() {
		return health;
	}
	vector<int> getAbilities() {
		return abilities;
	}
};
